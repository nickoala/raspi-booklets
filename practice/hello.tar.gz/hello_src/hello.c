#include <stdio.h>

void main() {
    printf("Hello, Mr C! You were born in 1972.\n");
}
