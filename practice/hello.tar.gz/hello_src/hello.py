print('Hello, Ms Python! You are definitely younger than Mr C.')
