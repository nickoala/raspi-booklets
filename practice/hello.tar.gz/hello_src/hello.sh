#!/bin/bash

echo "Hello, Mrs Bash! You look as young as Linux."
