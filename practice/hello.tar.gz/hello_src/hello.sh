#!/bin/bash

echo "Hello, Mrs Bash! You are at least as old as Linux."
