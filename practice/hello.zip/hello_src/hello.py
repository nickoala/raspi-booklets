print('Hello, Ms Python! You are younger than Mr C.')
